
public interface IFileEvent {
	void onFileAdded(String s);
}
