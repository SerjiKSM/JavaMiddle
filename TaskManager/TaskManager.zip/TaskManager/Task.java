
public interface Task {
    void execute();
}
